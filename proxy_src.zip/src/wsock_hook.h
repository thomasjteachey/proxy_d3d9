#pragma once

namespace WSockHook {
    void Install();
}
