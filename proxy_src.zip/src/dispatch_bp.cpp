#include "dispatch_bp.h"

// No-op. Opcode dispatch breakpoint logic is implemented in hitgate.cpp.

void DispatchBP::Install() {}
void DispatchBP::Remove() {}
