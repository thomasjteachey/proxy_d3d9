#pragma once
#include <d3d9.h>
void InstallEndSceneHook(IDirect3DDevice9* dev);
void InstallCombatHooks();
