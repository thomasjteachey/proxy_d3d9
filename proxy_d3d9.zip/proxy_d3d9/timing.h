#pragma once
double NowSecondsMonotonic();
