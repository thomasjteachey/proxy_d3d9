#pragma once

void OpcodeProbe_Init();

