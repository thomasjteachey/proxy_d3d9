#pragma once
void CallSplit_Init();   // call once from your InitHooksOnce()
